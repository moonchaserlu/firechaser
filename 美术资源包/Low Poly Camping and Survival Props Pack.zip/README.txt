Low Poly Camping & Survival Props Pack
======================================

30 game-ready low poly camping and survival props - a dome tent, an A-frame tent, a tarp shelter on poles and a toilet tent, rolled and open sleeping bags, a burning campfire and a stone fire ring, a cooking tripod with a pot, a two-burner camp stove, a kettle, gas and LED lanterns, a folding chair and table, a cooler box, large and small backpacks, a canteen, a first aid box, an axe in a chopping block, a firewood pile, a log bench, a hammock between posts, a fishing rod on a stand, a canoe and paddle, a rope coil, a trail sign post and a picnic blanket with a basket - in one consistent flat-shaded style.

STYLE
  Flat shaded low poly. Solid colour materials only - no image textures.
  Exactly 8 materials shared by every piece:
    canvas_orange    #E08240
    canvas_green     #4F7D42
    wood_log         #8B6239
    metal_dark       #49515B
    rope             #D8C69B
    fabric_blue      #3F6FA3
    flame            #FFAB33
    stone_grey       #909699
  flame is emissive (strength 1.0): the campfire, the embers, the gas
  lantern mantle and the LED lantern band light themselves.

SCALE / PIVOTS
  Real-world scale in metres. Origin at the base of each piece
  (min z = 0), centred in x/y, front facing -Y. All transforms
  applied. One UV layer per mesh. campfire drops straight into
  fire_ring_stones, and the kettle, stove and lanterns sit at 0.72 m,
  the height of folding_table.

FORMATS
  export/fbx/<piece>.fbx    - per piece, plus pack.fbx (grid layout)
  export/obj/<piece>.obj    - per piece, with .mtl
  export/glb/<piece>.glb    - per piece, plus pack.glb (grid layout)
  export/stl/<piece>.stl    - per piece, plus pack.stl
  export/pack.blend         - Blender scene with all pieces laid out

PIECES (30, 10708 triangles total)
  tent_dome                676 tris   3.04 x 4.00 x 1.36 m
  tent_a_frame             324 tris   3.68 x 4.84 x 1.69 m
  tarp_shelter             268 tris   4.78 x 3.98 x 1.99 m
  camp_toilet_tent         160 tris   2.10 x 2.10 x 2.12 m
  sleeping_bag_rolled      372 tris   0.39 x 0.67 x 0.39 m
  sleeping_bag_open        212 tris   1.05 x 1.94 x 0.28 m
  campfire                 554 tris   0.82 x 0.83 x 0.73 m
  fire_ring_stones         382 tris   1.67 x 1.73 x 0.41 m
  cooking_tripod           732 tris   1.77 x 1.52 x 1.69 m
  camp_stove               460 tris   0.92 x 0.68 x 0.47 m
  kettle                   272 tris   0.32 x 0.22 x 0.28 m
  lantern_gas              364 tris   0.23 x 0.21 x 0.47 m
  lantern_led              356 tris   0.18 x 0.18 x 0.31 m
  folding_chair            412 tris   0.72 x 0.54 x 0.89 m
  folding_table            220 tris   1.12 x 0.64 x 0.74 m
  cooler_box               168 tris   0.98 x 0.48 x 0.44 m
  backpack_large           348 tris   0.44 x 0.38 x 0.82 m
  backpack_small           152 tris   0.30 x 0.26 x 0.50 m
  canteen                  320 tris   0.28 x 0.13 x 0.31 m
  first_aid_box            148 tris   0.37 x 0.26 x 0.31 m
  axe_in_log               322 tris   1.46 x 1.08 x 1.10 m
  log_pile                 312 tris   1.57 x 1.75 x 0.87 m
  cut_log_seat             284 tris   2.10 x 0.87 x 0.62 m
  hammock                  344 tris   3.16 x 0.96 x 1.64 m
  fishing_rod_stand        458 tris   2.65 x 0.58 x 1.11 m
  canoe                    356 tris   3.63 x 0.88 x 0.66 m
  paddle                   116 tris   2.01 x 0.52 x 0.10 m
  rope_coil                652 tris   1.06 x 0.68 x 0.21 m
  trail_sign               324 tris   1.28 x 1.03 x 1.90 m
  picnic_blanket           640 tris   1.72 x 1.44 x 0.46 m

LICENCE
  CGTrader Royalty Free
